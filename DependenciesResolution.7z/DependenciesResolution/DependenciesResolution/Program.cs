﻿using System;

namespace DependenciesResolution
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("First ex:");
            DependenceInjection.AddTransient<IA, A>();
            DependenceInjection.AddTransient<IB, B>();
            DependenceInjection.Get<IA>();
            Console.WriteLine("Ex Singleton:");
            DependenceInjection.AddSingleton<MyClassSingleton, MyClassSingleton>();
            DependenceInjection.Get<MyClassSingleton>();
            DependenceInjection.Get<MyClassSingleton>();
            Console.WriteLine("Ex Transient:");
            DependenceInjection.AddTransient<MyClassTransient, MyClassTransient>();
            DependenceInjection.Get<MyClassTransient>();
            DependenceInjection.Get<MyClassTransient>();
            
        }
    }
}
