﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DependenciesResolution
{
    public interface IA
    {

    }
}
